var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-100vh";
  }
  prevScrollpos = currentScrollPos;
}

  function scrollUp() {
    window.scrollTo({ top: 0, behavior: 'smooth'});
  }
